import React from 'react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { 
  MessageCircle, 
  Settings, 
  User as UserIcon, 
  ChevronLeft, 
  ChevronRight,
  Bluetooth
} from 'lucide-react';
import { User } from '../App';
import { DashboardView } from './Dashboard';

interface SidebarProps {
  user: User;
  currentView: DashboardView;
  onViewChange: (view: DashboardView) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({ 
  user, 
  currentView, 
  onViewChange, 
  collapsed, 
  onToggleCollapse 
}: SidebarProps) {
  const menuItems = [
    {
      id: 'chats' as DashboardView,
      icon: MessageCircle,
      label: 'Chats',
      badge: 4
    },
    {
      id: 'profile' as DashboardView,
      icon: UserIcon,
      label: 'Profile'
    },
    {
      id: 'settings' as DashboardView,
      icon: Settings,
      label: 'Settings'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      default: return 'bg-slate-500';
    }
  };

  return (
    <div className={`bg-sidebar border-r border-sidebar-border transition-all duration-300 ${
      collapsed ? 'w-16' : 'w-64'
    }`}>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center justify-between">
            {!collapsed && (
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 dark:bg-blue-900/50 rounded-lg p-2">
                  <Bluetooth className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h1 className="tracking-wide">ProxiChat</h1>
                  <p className="text-xs text-sidebar-foreground/60">v1.0.0</p>
                </div>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleCollapse}
              className="p-1 h-auto"
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* User Profile */}
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Avatar className="w-10 h-10">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-sidebar ${
                getStatusColor(user.status)
              }`} />
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <p className="truncate">{user.name}</p>
                <p className="text-xs text-sidebar-foreground/60 capitalize">{user.status}</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "secondary" : "ghost"}
                className={`w-full justify-start h-11 ${
                  collapsed ? 'px-2' : 'px-4'
                } ${isActive ? 'bg-sidebar-accent text-sidebar-accent-foreground' : ''}`}
                onClick={() => onViewChange(item.id)}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && (
                  <>
                    <span className="ml-3">{item.label}</span>
                    {item.badge && (
                      <Badge className="ml-auto bg-blue-600 text-white">
                        {item.badge}
                      </Badge>
                    )}
                  </>
                )}
              </Button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border">
          {!collapsed && (
            <div className="text-xs text-sidebar-foreground/40 space-y-1">
              <p>© 2025 ProxiChat</p>
              <p>Secure Bluetooth Messaging</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}