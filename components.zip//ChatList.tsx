import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ScrollArea } from './ui/scroll-area';
import { 
  Plus, 
  Smartphone, 
  Laptop, 
  Tablet,
  Circle
} from 'lucide-react';
import { ChatDevice } from '../App';

interface ChatListProps {
  devices: ChatDevice[];
  selectedDevice: ChatDevice | null;
  onSelectDevice: (device: ChatDevice) => void;
  onShowDeviceDiscovery: () => void;
}

export function ChatList({ 
  devices, 
  selectedDevice, 
  onSelectDevice, 
  onShowDeviceDiscovery 
}: ChatListProps) {
  const getDeviceIcon = (deviceName: string) => {
    const name = deviceName.toLowerCase();
    if (name.includes('iphone') || name.includes('galaxy') || name.includes('pixel')) {
      return <Smartphone className="w-4 h-4" />;
    } else if (name.includes('macbook') || name.includes('laptop')) {
      return <Laptop className="w-4 h-4" />;
    } else if (name.includes('ipad') || name.includes('tablet')) {
      return <Tablet className="w-4 h-4" />;
    }
    return <Circle className="w-4 h-4" />;
  };

  const formatDistance = (distance: number) => {
    if (distance < 1) {
      return `${Math.round(distance * 100)}cm`;
    } else if (distance < 1000) {
      return `${distance.toFixed(1)}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  const formatLastSeen = (lastSeen: Date) => {
    const now = new Date();
    const diff = now.getTime() - lastSeen.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="tracking-tight">Nearby Devices</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={onShowDeviceDiscovery}
            className="flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Discover</span>
          </Button>
        </div>
        
        <div className="text-sm text-muted-foreground">
          {devices.length} device{devices.length !== 1 ? 's' : ''} found
        </div>
      </div>

      {/* Device List */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {devices.length > 0 ? (
            devices.map((device) => (
              <div
                key={device.id}
                onClick={() => onSelectDevice(device)}
                className={`p-3 rounded-lg cursor-pointer transition-colors mb-2 ${
                  selectedDevice?.id === device.id
                    ? 'bg-accent'
                    : 'hover:bg-accent/50'
                }`}
              >
                <div className="flex items-start space-x-3">
                  {/* Device Avatar */}
                  <div className="relative">
                    <Avatar className="w-10 h-10 bg-blue-100 dark:bg-blue-900/50">
                      <AvatarFallback className="text-blue-600">
                        {getDeviceIcon(device.name)}
                      </AvatarFallback>
                    </Avatar>
                    
                    {/* Connection Status */}
                    <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${
                      device.isConnected ? 'bg-green-500' : 'bg-slate-400'
                    }`} />
                  </div>

                  {/* Device Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="truncate pr-2">{device.name}</h3>
                      {device.unreadCount > 0 && (
                        <Badge className="bg-blue-600 text-white text-xs">
                          {device.unreadCount}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-muted-foreground mt-1">
                      <span>{formatDistance(device.distance)}</span>
                      <span>{formatLastSeen(device.lastSeen)}</span>
                    </div>
                    
                    <div className="flex items-center space-x-2 mt-1">
                      <div className={`w-2 h-2 rounded-full ${
                        device.isConnected ? 'bg-green-500' : 'bg-slate-400'
                      }`} />
                      <span className="text-xs text-muted-foreground">
                        {device.isConnected ? 'Connected' : 'Out of range'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-4xl mb-4">📱</div>
              <p className="mb-2">No devices found</p>
              <p className="text-sm">Make sure Bluetooth is enabled and devices are discoverable</p>
              <Button
                variant="outline"
                size="sm"
                onClick={onShowDeviceDiscovery}
                className="mt-4"
              >
                Start Discovery
              </Button>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}