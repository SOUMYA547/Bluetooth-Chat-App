import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Bluetooth, MessageCircle, Shield, Zap, ChevronRight, ChevronLeft } from 'lucide-react';

interface OnboardingFlowProps {
  onComplete: () => void;
}

interface OnboardingStep {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
}

export function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps: OnboardingStep[] = [
    {
      icon: <Bluetooth className="w-16 h-16 text-blue-500" />,
      title: "Bluetooth Proximity Chat",
      description: "Connect and chat with people nearby using Bluetooth technology",
      features: [
        "No internet required",
        "Automatic device discovery",
        "Range-based messaging"
      ]
    },
    {
      icon: <MessageCircle className="w-16 h-16 text-green-500" />,
      title: "Secure Messaging",
      description: "Send messages, photos, and files with end-to-end encryption",
      features: [
        "24-hour auto-delete",
        "File & image sharing",
        "Real-time delivery"
      ]
    },
    {
      icon: <Shield className="w-16 h-16 text-purple-500" />,
      title: "Privacy First",
      description: "Your conversations are private and automatically deleted",
      features: [
        "No data collection",
        "Local device storage",
        "Anonymous chatting"
      ]
    },
    {
      icon: <Zap className="w-16 h-16 text-yellow-500" />,
      title: "Ready to Connect",
      description: "Start discovering and chatting with nearby devices",
      features: [
        "Easy setup process",
        "Intuitive interface",
        "Cross-platform support"
      ]
    }
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const currentStepData = steps[currentStep];

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-8">
      <div className="w-full max-w-2xl">
        <Card className="p-12 text-center space-y-8 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-0 shadow-2xl">
          {/* Progress indicators */}
          <div className="flex justify-center space-x-2 mb-8">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentStep
                    ? 'bg-blue-500'
                    : index < currentStep
                    ? 'bg-blue-300'
                    : 'bg-slate-300 dark:bg-slate-600'
                }`}
              />
            ))}
          </div>

          {/* Icon */}
          <div className="flex justify-center">
            {currentStepData.icon}
          </div>

          {/* Content */}
          <div className="space-y-4">
            <h2 className="text-3xl">{currentStepData.title}</h2>
            <p className="text-lg text-muted-foreground">{currentStepData.description}</p>
          </div>

          {/* Features */}
          <ul className="space-y-3 text-left max-w-md mx-auto">
            {currentStepData.features.map((feature, index) => (
              <li key={index} className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                <span className="text-muted-foreground">{feature}</span>
              </li>
            ))}
          </ul>

          {/* Navigation */}
          <div className="flex justify-between items-center pt-8">
            <Button
              variant="ghost"
              onClick={prevStep}
              disabled={currentStep === 0}
              className="flex items-center space-x-2"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </Button>

            <Button
              onClick={nextStep}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
            >
              <span>{currentStep === steps.length - 1 ? "Get Started" : "Next"}</span>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Skip option */}
          {currentStep < steps.length - 1 && (
            <button
              onClick={onComplete}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Skip onboarding
            </button>
          )}
        </Card>
      </div>
    </div>
  );
}