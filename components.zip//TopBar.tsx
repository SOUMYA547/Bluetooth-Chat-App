import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  Search, 
  Bell, 
  Bluetooth, 
  BluetoothOff, 
  Moon, 
  Sun, 
  Plus,
  Wifi,
  WifiOff
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface TopBarProps {
  isBluetoothEnabled: boolean;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onShowDeviceDiscovery: () => void;
}

export function TopBar({ 
  isBluetoothEnabled, 
  isDarkMode, 
  onToggleDarkMode, 
  onShowDeviceDiscovery 
}: TopBarProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications] = useState([
    { id: '1', title: 'New device nearby', message: 'Sarah\'s iPhone is in range', time: '2m ago' },
    { id: '2', title: 'Message delivered', message: 'Your message to Mike was delivered', time: '5m ago' },
    { id: '3', title: 'Connection lost', message: 'Emma\'s Galaxy went out of range', time: '10m ago' }
  ]);

  return (
    <div className="h-16 border-b border-border bg-card px-6 flex items-center justify-between">
      {/* Left Section - Search */}
      <div className="flex items-center space-x-4 flex-1">
        <div className="relative w-80">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search devices or messages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-input-background border-0"
          />
        </div>
      </div>

      {/* Center Section - Status Indicators */}
      <div className="flex items-center space-x-4">
        {/* Bluetooth Status */}
        <div className="flex items-center space-x-2">
          {isBluetoothEnabled ? (
            <div className="flex items-center space-x-2 text-green-600">
              <Bluetooth className="w-4 h-4" />
              <span className="text-sm">Connected</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            </div>
          ) : (
            <div className="flex items-center space-x-2 text-red-600">
              <BluetoothOff className="w-4 h-4" />
              <span className="text-sm">Disconnected</span>
              <div className="w-2 h-2 bg-red-500 rounded-full" />
            </div>
          )}
        </div>

        {/* Network Status */}
        <div className="flex items-center space-x-2 text-muted-foreground">
          <WifiOff className="w-4 h-4" />
          <span className="text-sm">Offline Mode</span>
        </div>
      </div>

      {/* Right Section - Actions */}
      <div className="flex items-center space-x-2 flex-1 justify-end">
        {/* Add Device Button */}
        <Button
          variant="outline"
          size="sm"
          onClick={onShowDeviceDiscovery}
          className="flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Discover</span>
        </Button>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="relative">
              <Bell className="w-5 h-5" />
              {notifications.length > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center bg-red-500 text-white text-xs">
                  {notifications.length}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {notifications.length > 0 ? (
              notifications.map((notification) => (
                <DropdownMenuItem key={notification.id} className="flex flex-col items-start space-y-1 p-3">
                  <div className="flex justify-between w-full">
                    <span className="text-sm">{notification.title}</span>
                    <span className="text-xs text-muted-foreground">{notification.time}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{notification.message}</p>
                </DropdownMenuItem>
              ))
            ) : (
              <DropdownMenuItem disabled>No new notifications</DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-center text-sm text-blue-600">
              View all notifications
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Dark Mode Toggle */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleDarkMode}
        >
          {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </Button>
      </div>
    </div>
  );
}