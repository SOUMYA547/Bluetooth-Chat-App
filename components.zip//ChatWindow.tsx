import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Send, 
  Paperclip, 
  Image, 
  Clock, 
  Check, 
  CheckCheck,
  MoreVertical,
  Smartphone
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { ChatDevice, Message } from '../App';

interface ChatWindowProps {
  device: ChatDevice;
  messages: Message[];
  onSendMessage: (content: string) => void;
}

export function ChatWindow({ device, messages, onSendMessage }: ChatWindowProps) {
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleSend = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage.trim());
      setNewMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatMessageDate = (timestamp: Date) => {
    const now = new Date();
    const messageDate = new Date(timestamp);
    const diffDays = Math.floor((now.getTime() - messageDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    return messageDate.toLocaleDateString();
  };

  const getTimeRemaining = () => {
    // Calculate 24 hours from the oldest message
    if (messages.length === 0) return null;
    
    const oldestMessage = messages[0];
    const deleteTime = new Date(oldestMessage.timestamp.getTime() + 24 * 60 * 60 * 1000);
    const now = new Date();
    const remaining = deleteTime.getTime() - now.getTime();
    
    if (remaining <= 0) return null;
    
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };

  const timeRemaining = getTimeRemaining();

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Chat Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center">
                <Smartphone className="w-5 h-5 text-blue-600" />
              </div>
              <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${
                device.isConnected ? 'bg-green-500' : 'bg-slate-400'
              }`} />
            </div>
            <div>
              <h3>{device.name}</h3>
              <p className="text-sm text-muted-foreground">
                {device.isConnected ? `Connected • ${device.distance.toFixed(1)}m away` : 'Disconnected'}
              </p>
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>View device info</DropdownMenuItem>
              <DropdownMenuItem>Clear chat history</DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">Block device</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Auto-delete Banner */}
      {timeRemaining && (
        <Alert className="m-4 border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-900/20">
          <Clock className="w-4 h-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800 dark:text-yellow-200">
            Messages will auto-delete in {timeRemaining}
          </AlertDescription>
        </Alert>
      )}

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length > 0 ? (
            messages.map((message, index) => {
              const showDateSeparator = index === 0 || 
                formatMessageDate(messages[index - 1].timestamp) !== formatMessageDate(message.timestamp);

              return (
                <div key={message.id}>
                  {showDateSeparator && (
                    <div className="flex justify-center my-4">
                      <span className="bg-muted text-muted-foreground text-sm px-3 py-1 rounded-full">
                        {formatMessageDate(message.timestamp)}
                      </span>
                    </div>
                  )}
                  
                  <div className={`flex ${message.isSent ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                      message.isSent 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-muted'
                    }`}>
                      {message.hasAttachment && (
                        <div className="mb-2">
                          {message.attachmentType === 'image' ? (
                            <div className="w-48 h-32 bg-muted-foreground/20 rounded-lg flex items-center justify-center">
                              <Image className="w-8 h-8 text-muted-foreground" />
                            </div>
                          ) : (
                            <div className="flex items-center space-x-2 p-2 bg-muted-foreground/20 rounded-lg">
                              <Paperclip className="w-4 h-4" />
                              <span className="text-sm">document.pdf</span>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <p className="break-words">{message.content}</p>
                      
                      <div className={`flex items-center justify-end mt-2 space-x-1 text-xs ${
                        message.isSent ? 'text-white/70' : 'text-muted-foreground'
                      }`}>
                        <span>{formatTime(message.timestamp)}</span>
                        {message.isSent && (
                          <CheckCheck className="w-3 h-3" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-4xl mb-4">💬</div>
              <p className="mb-2">No messages yet</p>
              <p className="text-sm">Start a conversation with {device.name}</p>
            </div>
          )}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-muted rounded-2xl px-4 py-3 max-w-[70%]">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Message Input */}
      <div className="p-4 border-t border-border bg-card">
        <div className="flex items-end space-x-3">
          {/* Attachment Buttons */}
          <div className="flex space-x-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => imageInputRef.current?.click()}
              disabled={!device.isConnected}
            >
              <Image className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={!device.isConnected}
            >
              <Paperclip className="w-4 h-4" />
            </Button>
          </div>

          {/* Message Input */}
          <div className="flex-1">
            <Input
              placeholder={device.isConnected ? "Type a message..." : "Device not connected"}
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={!device.isConnected}
              className="resize-none"
            />
          </div>

          {/* Send Button */}
          <Button
            onClick={handleSend}
            disabled={!newMessage.trim() || !device.isConnected}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {!device.isConnected && (
          <p className="text-sm text-muted-foreground mt-2 text-center">
            Device is out of range. Messages will be sent when connection is restored.
          </p>
        )}
      </div>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={(e) => {
          // Handle file attachment
          console.log('File selected:', e.target.files?.[0]);
        }}
      />
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          // Handle image attachment
          console.log('Image selected:', e.target.files?.[0]);
        }}
      />
    </div>
  );
}