import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { 
  Bluetooth, 
  Smartphone, 
  Laptop, 
  Tablet, 
  RefreshCw,
  Wifi,
  Circle
} from 'lucide-react';
import { ChatDevice } from '../App';

interface DeviceDiscoveryModalProps {
  onClose: () => void;
  onDeviceSelect: (device: ChatDevice) => void;
}

interface DiscoveredDevice {
  id: string;
  name: string;
  type: 'phone' | 'laptop' | 'tablet' | 'unknown';
  distance: number;
  signal: number;
  isConnectable: boolean;
}

export function DeviceDiscoveryModal({ onClose, onDeviceSelect }: DeviceDiscoveryModalProps) {
  const [isScanning, setIsScanning] = useState(true);
  const [scanProgress, setScanProgress] = useState(0);
  const [discoveredDevices, setDiscoveredDevices] = useState<DiscoveredDevice[]>([]);

  // Mock device discovery simulation
  useEffect(() => {
    if (!isScanning) return;

    const mockDevices: DiscoveredDevice[] = [
      {
        id: 'disc-1',
        name: 'John\'s iPhone 15',
        type: 'phone',
        distance: 3.2,
        signal: 85,
        isConnectable: true
      },
      {
        id: 'disc-2',
        name: 'Office-MacBook-Pro',
        type: 'laptop',
        distance: 8.7,
        signal: 62,
        isConnectable: true
      },
      {
        id: 'disc-3',
        name: 'Lisa\'s Galaxy Tab',
        type: 'tablet',
        distance: 12.1,
        signal: 45,
        isConnectable: false
      },
      {
        id: 'disc-4',
        name: 'Unknown Device',
        type: 'unknown',
        distance: 15.8,
        signal: 28,
        isConnectable: false
      }
    ];

    let currentProgress = 0;
    let deviceIndex = 0;

    const interval = setInterval(() => {
      currentProgress += 10;
      setScanProgress(currentProgress);

      // Add devices progressively
      if (currentProgress >= 25 && deviceIndex < mockDevices.length) {
        setDiscoveredDevices(prev => [...prev, mockDevices[deviceIndex]]);
        deviceIndex++;
      }

      if (currentProgress >= 100) {
        setIsScanning(false);
        clearInterval(interval);
      }
    }, 300);

    return () => clearInterval(interval);
  }, [isScanning]);

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'phone': return <Smartphone className="w-5 h-5" />;
      case 'laptop': return <Laptop className="w-5 h-5" />;
      case 'tablet': return <Tablet className="w-5 h-5" />;
      default: return <Circle className="w-5 h-5" />;
    }
  };

  const getSignalStrength = (signal: number) => {
    if (signal >= 70) return 'Strong';
    if (signal >= 40) return 'Moderate';
    return 'Weak';
  };

  const getSignalColor = (signal: number) => {
    if (signal >= 70) return 'text-green-600';
    if (signal >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const handleConnect = (device: DiscoveredDevice) => {
    if (!device.isConnectable) return;

    const newChatDevice: ChatDevice = {
      id: device.id,
      name: device.name,
      distance: device.distance,
      lastSeen: new Date(),
      isConnected: true,
      unreadCount: 0
    };

    onDeviceSelect(newChatDevice);
  };

  const restartScan = () => {
    setIsScanning(true);
    setScanProgress(0);
    setDiscoveredDevices([]);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Bluetooth className="w-5 h-5 text-blue-600" />
            <span>Discover Nearby Devices</span>
          </DialogTitle>
          <DialogDescription>
            Scanning for Bluetooth devices in your area. Make sure other devices are discoverable.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Scan Progress */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">
                {isScanning ? 'Scanning...' : 'Scan Complete'}
              </span>
              <span className="text-sm text-muted-foreground">
                {scanProgress}%
              </span>
            </div>
            <Progress value={scanProgress} className="h-2" />
            
            {isScanning && (
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Searching for devices...</span>
              </div>
            )}
          </div>

          {/* Discovered Devices */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4>Discovered Devices</h4>
              <span className="text-sm text-muted-foreground">
                {discoveredDevices.length} found
              </span>
            </div>

            <div className="max-h-64 overflow-y-auto space-y-2">
              {discoveredDevices.length > 0 ? (
                discoveredDevices.map((device) => (
                  <div
                    key={device.id}
                    className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-accent transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="text-blue-600">
                        {getDeviceIcon(device.type)}
                      </div>
                      <div>
                        <h5 className="text-sm">{device.name}</h5>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>{device.distance.toFixed(1)}m away</span>
                          <span className={getSignalColor(device.signal)}>
                            {getSignalStrength(device.signal)} signal
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {!device.isConnectable && (
                        <Badge variant="secondary" className="text-xs">
                          Not available
                        </Badge>
                      )}
                      <Button
                        size="sm"
                        variant={device.isConnectable ? "default" : "ghost"}
                        onClick={() => handleConnect(device)}
                        disabled={!device.isConnectable}
                        className="text-xs"
                      >
                        {device.isConnectable ? 'Connect' : 'Unavailable'}
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Bluetooth className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No devices found yet</p>
                  <p className="text-xs">Make sure Bluetooth is enabled on nearby devices</p>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={restartScan}
              disabled={isScanning}
              className="flex items-center space-x-2"
            >
              <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
              <span>Rescan</span>
            </Button>

            <div className="space-x-2">
              <Button variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={onClose} disabled={discoveredDevices.length === 0}>
                Done
              </Button>
            </div>
          </div>

          {/* Help Text */}
          <div className="text-xs text-muted-foreground text-center space-y-1">
            <p>💡 Tip: Devices must be within 30 meters and have Bluetooth enabled</p>
            <p>Some devices may not be discoverable for privacy reasons</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}