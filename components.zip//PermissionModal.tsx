import React from 'react';
import { Button } from './ui/button';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Bluetooth, 
  MapPin, 
  Bell, 
  Shield, 
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface PermissionModalProps {
  type: 'bluetooth' | 'location' | 'notifications';
  onAllow: () => void;
  onDeny: () => void;
}

export function PermissionModal({ type, onAllow, onDeny }: PermissionModalProps) {
  const getPermissionConfig = () => {
    switch (type) {
      case 'bluetooth':
        return {
          icon: <Bluetooth className="w-12 h-12 text-blue-600" />,
          title: 'Bluetooth Permission Required',
          description: 'ProxiChat needs access to Bluetooth to discover and connect with nearby devices.',
          features: [
            'Discover nearby Bluetooth devices',
            'Connect and communicate with approved devices',
            'Share your device name with others',
            'Automatically reconnect to known devices'
          ],
          importance: 'Required for core functionality',
          color: 'blue'
        };
      case 'location':
        return {
          icon: <MapPin className="w-12 h-12 text-green-600" />,
          title: 'Location Permission',
          description: 'Location access helps improve Bluetooth device discovery and shows approximate distances.',
          features: [
            'More accurate device discovery',
            'Show distance to nearby devices',
            'Better connection reliability',
            'Improved proximity detection'
          ],
          importance: 'Recommended for better experience',
          color: 'green'
        };
      case 'notifications':
        return {
          icon: <Bell className="w-12 h-12 text-purple-600" />,
          title: 'Notification Permission',
          description: 'Get notified when you receive messages or when devices connect/disconnect.',
          features: [
            'Instant message notifications',
            'Device connection alerts',
            'New device discovery notifications',
            'Background activity updates'
          ],
          importance: 'Recommended to stay connected',
          color: 'purple'
        };
    }
  };

  const config = getPermissionConfig();

  return (
    <Dialog open={true} onOpenChange={onDeny}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            {config.icon}
          </div>
          <DialogTitle className="text-center">{config.title}</DialogTitle>
          <DialogDescription className="text-center">
            {config.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Features list */}
          <div className="space-y-3">
            <h4 className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span>This permission allows ProxiChat to:</span>
            </h4>
            <ul className="space-y-2 ml-6">
              {config.features.map((feature, index) => (
                <li key={index} className="flex items-start space-x-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full mt-2 flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Importance level */}
          <Alert className={`border-${config.color}-200 bg-${config.color}-50 dark:border-${config.color}-800 dark:bg-${config.color}-900/20`}>
            {type === 'bluetooth' ? (
              <AlertTriangle className="w-4 h-4 text-orange-600" />
            ) : (
              <Shield className="w-4 h-4 text-blue-600" />
            )}
            <AlertDescription className="text-sm">
              <strong>Importance:</strong> {config.importance}
            </AlertDescription>
          </Alert>

          {/* Privacy notice */}
          <div className="text-xs text-muted-foreground bg-muted p-3 rounded-lg space-y-1">
            <p className="flex items-center space-x-2">
              <Shield className="w-3 h-3" />
              <span><strong>Privacy Notice:</strong></span>
            </p>
            <ul className="space-y-1 ml-5">
              <li>• Your data stays on your device</li>
              <li>• No information is sent to external servers</li>
              <li>• You can revoke permissions anytime in settings</li>
              <li>• All communications are encrypted end-to-end</li>
            </ul>
          </div>

          {/* Additional info for Bluetooth */}
          {type === 'bluetooth' && (
            <Alert>
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                Without Bluetooth permission, ProxiChat cannot function. You can change this permission later in your system settings.
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter className="flex justify-between sm:justify-between">
          <Button
            variant="outline"
            onClick={onDeny}
            className="flex-1 mr-2"
          >
            {type === 'bluetooth' ? 'Not Now' : 'Deny'}
          </Button>
          <Button
            onClick={onAllow}
            className={`flex-1 ml-2 bg-${config.color}-600 hover:bg-${config.color}-700`}
          >
            {type === 'bluetooth' ? 'Enable Bluetooth' : 'Allow'}
          </Button>
        </DialogFooter>

        {/* Help text */}
        <div className="text-center text-xs text-muted-foreground">
          You can manage all permissions in Settings → Privacy
        </div>
      </DialogContent>
    </Dialog>
  );
}