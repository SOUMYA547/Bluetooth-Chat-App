import React from 'react';
import { Bluetooth } from 'lucide-react';

export function SplashScreen() {
  return (
    <div className="size-full flex flex-col items-center justify-center bg-gradient-to-br from-blue-600 to-purple-700 text-white">
      <div className="flex flex-col items-center space-y-8 animate-pulse">
        {/* Logo */}
        <div className="relative">
          <div className="absolute inset-0 bg-white/20 rounded-full blur-xl animate-ping"></div>
          <div className="relative bg-white/10 backdrop-blur-sm rounded-full p-8 border border-white/20">
            <Bluetooth className="w-16 h-16" />
          </div>
        </div>

        {/* Brand Name */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl tracking-wide">ProxiChat</h1>
          <p className="text-lg text-white/80">Connect. Chat. Discover.</p>
        </div>
      </div>

      {/* Loading indicator */}
      <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
        <div className="flex space-x-2">
          <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce"></div>
          <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
          <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
        </div>
      </div>
    </div>
  );
}