import React, { useState } from 'react';
import { TopBar } from './TopBar';
import { Sidebar } from './Sidebar';
import { ChatList } from './ChatList';
import { ChatWindow } from './ChatWindow';
import { SettingsPanel } from './SettingsPanel';
import { ProfilePanel } from './ProfilePanel';
import { User, ChatDevice, Message } from '../App';

interface DashboardProps {
  user: User;
  devices: ChatDevice[];
  messages: Message[];
  isBluetoothEnabled: boolean;
  isDarkMode: boolean;
  onSendMessage: (content: string, deviceId: string) => void;
  onToggleDarkMode: () => void;
  onShowDeviceDiscovery: () => void;
  onShowPermissionModal: (type: 'bluetooth' | 'location' | 'notifications') => void;
  onUpdateUser?: (user: User) => void;
}

export type DashboardView = 'chats' | 'settings' | 'profile';

export function Dashboard({
  user,
  devices,
  messages,
  isBluetoothEnabled,
  isDarkMode,
  onSendMessage,
  onToggleDarkMode,
  onShowDeviceDiscovery,
  onShowPermissionModal,
  onUpdateUser
}: DashboardProps) {
  const [currentView, setCurrentView] = useState<DashboardView>('chats');
  const [selectedDevice, setSelectedDevice] = useState<ChatDevice | null>(devices[0] || null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const filteredMessages = selectedDevice 
    ? messages.filter(m => m.deviceId === selectedDevice.id)
    : [];

  const renderMainContent = () => {
    switch (currentView) {
      case 'profile':
        return (
          <ProfilePanel
            user={user}
            onUpdateUser={onUpdateUser}
          />
        );
      case 'settings':
        return (
          <SettingsPanel
            user={user}
            isDarkMode={isDarkMode}
            isBluetoothEnabled={isBluetoothEnabled}
            onToggleDarkMode={onToggleDarkMode}
            onShowPermissionModal={onShowPermissionModal}
          />
        );
      case 'chats':
      default:
        return (
          <div className="flex flex-1 h-full">
            {/* Chat List */}
            <div className="w-80 border-r border-border bg-card">
              <ChatList
                devices={devices}
                selectedDevice={selectedDevice}
                onSelectDevice={setSelectedDevice}
                onShowDeviceDiscovery={onShowDeviceDiscovery}
              />
            </div>

            {/* Chat Window */}
            <div className="flex-1">
              {selectedDevice ? (
                <ChatWindow
                  device={selectedDevice}
                  messages={filteredMessages}
                  onSendMessage={(content) => onSendMessage(content, selectedDevice.id)}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center space-y-2">
                    <div className="text-4xl">💬</div>
                    <p>Select a device to start chatting</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar
        user={user}
        currentView={currentView}
        onViewChange={setCurrentView}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content */}
      <div className="flex flex-col flex-1">
        {/* Top Bar */}
        <TopBar
          isBluetoothEnabled={isBluetoothEnabled}
          isDarkMode={isDarkMode}
          onToggleDarkMode={onToggleDarkMode}
          onShowDeviceDiscovery={onShowDeviceDiscovery}
        />

        {/* Content Area */}
        <div className="flex-1 overflow-hidden">
          {renderMainContent()}
        </div>
      </div>
    </div>
  );
}