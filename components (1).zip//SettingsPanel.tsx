import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { 
  User as UserIcon, 
  Shield, 
  Palette, 
  Bell, 
  Camera, 
  Moon,
  Volume2,
  Bluetooth,
  Eye,
  Lock,
  Clock
} from 'lucide-react';
import { User } from '../App';

interface SettingsPanelProps {
  user: User;
  isDarkMode: boolean;
  isBluetoothEnabled: boolean;
  onToggleDarkMode: () => void;
  onShowPermissionModal: (type: 'bluetooth' | 'location' | 'notifications') => void;
}

export function SettingsPanel({ 
  user, 
  isDarkMode, 
  isBluetoothEnabled,
  onToggleDarkMode, 
  onShowPermissionModal 
}: SettingsPanelProps) {
  const [profileData, setProfileData] = useState({
    name: user.name,
    status: user.status,
    bio: 'Available for proximity chat'
  });
  
  const [privacySettings, setPrivacySettings] = useState({
    discoverable: true,
    allowConnections: true,
    shareLocation: false,
    autoAcceptFiles: false,
    blockUnknown: false
  });

  const [notificationSettings, setNotificationSettings] = useState({
    messageNotifications: true,
    deviceDiscovery: true,
    connectionAlerts: true,
    soundEnabled: true,
    volume: [75]
  });

  const [appearanceSettings, setAppearanceSettings] = useState({
    messageSize: 'medium',
    showTimestamps: true,
    compactMode: false
  });

  const handleProfileUpdate = () => {
    // Handle profile update
    console.log('Profile updated:', profileData);
  };

  const handlePrivacyChange = (setting: string, value: boolean) => {
    setPrivacySettings(prev => ({ ...prev, [setting]: value }));
  };

  const handleNotificationChange = (setting: string, value: boolean) => {
    setNotificationSettings(prev => ({ ...prev, [setting]: value }));
  };

  const handleAppearanceChange = (setting: string, value: any) => {
    setAppearanceSettings(prev => ({ ...prev, [setting]: value }));
  };

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl mb-2">Settings</h1>
          <p className="text-muted-foreground">Manage your ProxiChat preferences and privacy settings</p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <UserIcon className="w-4 h-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger value="privacy" className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Privacy</span>
            </TabsTrigger>
            <TabsTrigger value="appearance" className="flex items-center space-x-2">
              <Palette className="w-4 h-4" />
              <span>Appearance</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center space-x-2">
              <Bell className="w-4 h-4" />
              <span>Notifications</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>
                  Update your profile details and status
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Avatar */}
                <div className="flex items-center space-x-4">
                  <Avatar className="w-20 h-20">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <Button variant="outline" className="flex items-center space-x-2">
                      <Camera className="w-4 h-4" />
                      <span>Change Photo</span>
                    </Button>
                    <p className="text-sm text-muted-foreground mt-1">
                      JPG, PNG or GIF (max 2MB)
                    </p>
                  </div>
                </div>

                {/* Name */}
                <div className="space-y-2">
                  <Label htmlFor="name">Display Name</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter your display name"
                  />
                </div>

                {/* Status */}
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={profileData.status} onValueChange={(value) => 
                    setProfileData(prev => ({ ...prev, status: value as any }))
                  }>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="online">🟢 Online</SelectItem>
                      <SelectItem value="away">🟡 Away</SelectItem>
                      <SelectItem value="busy">🔴 Busy</SelectItem>
                      <SelectItem value="offline">⚫ Offline</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Bio */}
                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Input
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell others about yourself"
                  />
                </div>

                <Button onClick={handleProfileUpdate}>
                  Save Changes
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Privacy & Security</CardTitle>
                <CardDescription>
                  Control who can find and connect to your device
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Discoverable */}
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4" />
                      <span>Make device discoverable</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Allow nearby devices to find and connect to you
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.discoverable}
                    onCheckedChange={(checked) => handlePrivacyChange('discoverable', checked)}
                  />
                </div>

                {/* Auto-accept connections */}
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <Bluetooth className="w-4 h-4" />
                      <span>Auto-accept connections</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Automatically accept connection requests from nearby devices
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.allowConnections}
                    onCheckedChange={(checked) => handlePrivacyChange('allowConnections', checked)}
                  />
                </div>

                {/* Location sharing */}
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span>Share location info</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Share approximate distance with connected devices
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.shareLocation}
                    onCheckedChange={(checked) => handlePrivacyChange('shareLocation', checked)}
                  />
                </div>

                {/* Auto-accept files */}
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <span>Auto-accept file transfers</span>
                    <p className="text-sm text-muted-foreground">
                      Automatically accept file transfers from trusted devices
                    </p>
                  </div>
                  <Switch
                    checked={privacySettings.autoAcceptFiles}
                    onCheckedChange={(checked) => handlePrivacyChange('autoAcceptFiles', checked)}
                  />
                </div>

                {/* Message retention */}
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4" />
                    <span>Message Auto-Delete</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Messages are automatically deleted after 24 hours for privacy
                  </p>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm">🔒 This setting cannot be changed for security reasons</p>
                  </div>
                </div>

                {/* Permission buttons */}
                <div className="space-y-3">
                  <h4 className="flex items-center space-x-2">
                    <Lock className="w-4 h-4" />
                    <span>Permissions</span>
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      variant="outline"
                      onClick={() => onShowPermissionModal('bluetooth')}
                      className="justify-start"
                    >
                      Configure Bluetooth Permissions
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => onShowPermissionModal('location')}
                      className="justify-start"
                    >
                      Configure Location Permissions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Appearance</CardTitle>
                <CardDescription>
                  Customize the look and feel of ProxiChat
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Theme Info */}
                <div className="space-y-3">
                  <Label>Theme</Label>
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Moon className="w-4 h-4 text-blue-500" />
                      <span>Dark Mode Active</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      ProxiChat uses dark mode for better privacy and reduced eye strain during night communications.
                    </p>
                  </div>
                </div>

                {/* Message size */}
                <div className="space-y-3">
                  <Label>Message Size</Label>
                  <Select 
                    value={appearanceSettings.messageSize} 
                    onValueChange={(value) => handleAppearanceChange('messageSize', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show timestamps */}
                <div className="flex items-center justify-between">
                  <div>
                    <span>Show message timestamps</span>
                    <p className="text-sm text-muted-foreground">
                      Display time stamps on all messages
                    </p>
                  </div>
                  <Switch
                    checked={appearanceSettings.showTimestamps}
                    onCheckedChange={(checked) => handleAppearanceChange('showTimestamps', checked)}
                  />
                </div>

                {/* Compact mode */}
                <div className="flex items-center justify-between">
                  <div>
                    <span>Compact mode</span>
                    <p className="text-sm text-muted-foreground">
                      Use a more compact interface layout
                    </p>
                  </div>
                  <Switch
                    checked={appearanceSettings.compactMode}
                    onCheckedChange={(checked) => handleAppearanceChange('compactMode', checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>
                  Configure when and how you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Message notifications */}
                <div className="flex items-center justify-between">
                  <div>
                    <span>Message notifications</span>
                    <p className="text-sm text-muted-foreground">
                      Get notified when you receive new messages
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.messageNotifications}
                    onCheckedChange={(checked) => handleNotificationChange('messageNotifications', checked)}
                  />
                </div>

                {/* Device discovery */}
                <div className="flex items-center justify-between">
                  <div>
                    <span>Device discovery</span>
                    <p className="text-sm text-muted-foreground">
                      Get notified when new devices are found nearby
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.deviceDiscovery}
                    onCheckedChange={(checked) => handleNotificationChange('deviceDiscovery', checked)}
                  />
                </div>

                {/* Connection alerts */}
                <div className="flex items-center justify-between">
                  <div>
                    <span>Connection alerts</span>
                    <p className="text-sm text-muted-foreground">
                      Get notified when devices connect or disconnect
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.connectionAlerts}
                    onCheckedChange={(checked) => handleNotificationChange('connectionAlerts', checked)}
                  />
                </div>

                {/* Sound */}
                <div className="flex items-center justify-between">
                  <div>
                    <span>Sound notifications</span>
                    <p className="text-sm text-muted-foreground">
                      Play sounds for notifications
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.soundEnabled}
                    onCheckedChange={(checked) => handleNotificationChange('soundEnabled', checked)}
                  />
                </div>

                {/* Volume */}
                {notificationSettings.soundEnabled && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center space-x-2">
                        <Volume2 className="w-4 h-4" />
                        <span>Notification Volume</span>
                      </Label>
                      <span className="text-sm text-muted-foreground">
                        {notificationSettings.volume[0]}%
                      </span>
                    </div>
                    <Slider
                      value={notificationSettings.volume}
                      onValueChange={(value) => 
                        setNotificationSettings(prev => ({ ...prev, volume: value }))
                      }
                      max={100}
                      step={5}
                      className="w-full"
                    />
                  </div>
                )}

                {/* Permission button */}
                <div className="pt-4">
                  <Button
                    variant="outline"
                    onClick={() => onShowPermissionModal('notifications')}
                    className="flex items-center space-x-2"
                  >
                    <Bell className="w-4 h-4" />
                    <span>Configure System Notifications</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}