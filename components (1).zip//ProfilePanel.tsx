import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { 
  User as UserIcon, 
  Edit, 
  Camera, 
  Shield, 
  Activity,
  Bluetooth,
  Wifi,
  Battery,
  Clock
} from 'lucide-react';
import { User } from '../App';

interface ProfilePanelProps {
  user: User;
  onUpdateUser?: (user: User) => void;
}

export function ProfilePanel({ user, onUpdateUser }: ProfilePanelProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState(user);

  const handleSave = () => {
    if (onUpdateUser) {
      onUpdateUser(editedUser);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedUser(user);
    setIsEditing(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      default: return 'bg-slate-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'online': return 'Online';
      case 'away': return 'Away';
      case 'busy': return 'Busy';
      default: return 'Offline';
    }
  };

  return (
    <div className="flex-1 overflow-auto bg-background">
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Profile</h1>
            <p className="text-muted-foreground">Manage your ProxiChat profile and preferences</p>
          </div>
          <Button 
            variant={isEditing ? "outline" : "default"}
            onClick={() => setIsEditing(!isEditing)}
          >
            <Edit className="w-4 h-4 mr-2" />
            {isEditing ? 'Cancel' : 'Edit Profile'}
          </Button>
        </div>

        {/* Profile Information */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>Your basic profile information and status</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Avatar Section */}
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={editedUser.avatar} alt={editedUser.name} />
                  <AvatarFallback className="text-xl">
                    {editedUser.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-background ${
                  getStatusColor(editedUser.status)
                }`} />
                {isEditing && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="absolute -bottom-2 left-1/2 transform -translate-x-1/2"
                  >
                    <Camera className="w-3 h-3" />
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                <div>
                  <Label htmlFor="name">Display Name</Label>
                  {isEditing ? (
                    <Input
                      id="name"
                      value={editedUser.name}
                      onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                      className="mt-1"
                    />
                  ) : (
                    <p className="text-lg font-medium">{user.name}</p>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className={`${getStatusColor(user.status)}`}>
                    <div className={`w-2 h-2 rounded-full mr-2 ${getStatusColor(user.status)}`} />
                    {getStatusLabel(user.status)}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Status Selection */}
            {isEditing && (
              <div className="space-y-2">
                <Label>Status</Label>
                <div className="flex space-x-2">
                  {['online', 'away', 'busy', 'offline'].map((status) => (
                    <Button
                      key={status}
                      variant={editedUser.status === status ? "default" : "outline"}
                      size="sm"
                      onClick={() => setEditedUser({ ...editedUser, status: status as User['status'] })}
                    >
                      <div className={`w-2 h-2 rounded-full mr-2 ${getStatusColor(status)}`} />
                      {getStatusLabel(status)}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {isEditing && (
              <div className="flex space-x-2">
                <Button onClick={handleSave}>Save Changes</Button>
                <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Account Details */}
        <Card>
          <CardHeader>
            <CardTitle>Account Details</CardTitle>
            <CardDescription>Your account information and security</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">User ID</Label>
                <p className="text-sm text-muted-foreground font-mono">{user.id}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Account Type</Label>
                <p className="text-sm text-muted-foreground">Premium User</p>
              </div>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-green-500" />
                <span className="text-sm">Security Status</span>
              </div>
              <Badge variant="outline" className="text-green-600 border-green-600">
                Secure
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Device & Connection Info */}
        <Card>
          <CardHeader>
            <CardTitle>Device & Connection</CardTitle>
            <CardDescription>Current device status and connectivity information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <Bluetooth className="w-5 h-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Bluetooth</p>
                  <p className="text-xs text-muted-foreground">Connected</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Wifi className="w-5 h-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Network</p>
                  <p className="text-xs text-muted-foreground">Local Only</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Battery className="w-5 h-5 text-yellow-500" />
                <div>
                  <p className="text-sm font-medium">Battery</p>
                  <p className="text-xs text-muted-foreground">85%</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Clock className="w-5 h-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Last Sync</p>
                  <p className="text-xs text-muted-foreground">2 min ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Activity Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Activity Overview</CardTitle>
            <CardDescription>Your ProxiChat usage statistics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="space-y-2">
                <Activity className="w-8 h-8 mx-auto text-blue-500" />
                <div>
                  <p className="text-2xl font-bold">127</p>
                  <p className="text-xs text-muted-foreground">Messages Sent</p>
                </div>
              </div>
              <div className="space-y-2">
                <UserIcon className="w-8 h-8 mx-auto text-green-500" />
                <div>
                  <p className="text-2xl font-bold">8</p>
                  <p className="text-xs text-muted-foreground">Connections</p>
                </div>
              </div>
              <div className="space-y-2">
                <Clock className="w-8 h-8 mx-auto text-purple-500" />
                <div>
                  <p className="text-2xl font-bold">24h</p>
                  <p className="text-xs text-muted-foreground">Online Time</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}